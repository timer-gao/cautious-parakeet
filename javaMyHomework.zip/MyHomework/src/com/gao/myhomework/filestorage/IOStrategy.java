package com.gao.myhomework.filestorage;

import java.net.*;

/*
	�ṩЭ����Զ���
*/

public interface IOStrategy
{
	public void service(Socket socket);
}
